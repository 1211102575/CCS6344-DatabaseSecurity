<?php
$serverName = "IMS-Server";
$connectionOptions = array(
    "Database" => "InventoryManagementSystem",
    "Uid" => "NotSa", 
    "PWD" => "Password!123"
);

$conn = sqlsrv_connect($serverName, $connectionOptions);

if ($conn === false) {
    die(print_r(sqlsrv_errors(), true));
}
?>