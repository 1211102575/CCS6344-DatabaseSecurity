<?php
include 'db.php';

$sql = "SELECT * FROM TotalCounts";
$stmt = sqlsrv_query($conn, $sql);

$row = sqlsrv_fetch_array($stmt, SQLSRV_FETCH_ASSOC);

header('Content-Type: application/json');
echo json_encode($row);
?>