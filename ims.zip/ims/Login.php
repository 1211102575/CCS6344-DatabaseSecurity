<?php
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: POST");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

require_once 'db.php';

$data = json_decode(file_get_contents("php://input"), true);

$username = $data['username'];
$password = $data['password'];

$sql = "SELECT UserID, UserName, PasswordHash, RoleID FROM UserSchema.Users WHERE UserName = ?";
$params = array($username);
$stmt = sqlsrv_query($conn, $sql, $params);

if ($stmt === false) {
    die(print_r(sqlsrv_errors(), true));
}

$row = sqlsrv_fetch_array($stmt, SQLSRV_FETCH_ASSOC);

if ($row) {
    $passwordUtf16 = mb_convert_encoding($password, 'UTF-16LE');
    $inputHash = strtoupper(hash('sha256', $passwordUtf16));

    if ($inputHash == $row['PasswordHash']) {
        $token = bin2hex(random_bytes(16));
        echo json_encode(array(
            "status" => "success",
            "token" => $token,
            "userID" => $row['UserID'],
            "roleID" => $row['RoleID']
        ));
    } else {
        http_response_code(401);
        echo json_encode(array("status" => "error", "message" => "Invalid credentials"));
    }
} else {
    http_response_code(404);
    echo json_encode(array("status" => "error", "message" => "User not found"));
}
sqlsrv_close($conn);
?>