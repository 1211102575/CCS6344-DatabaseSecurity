const sql = require('mssql');

const config = {
  server: 'DESKTOP-GTOMBCH',    // Replace with your server name or IP address
  database: 'your-database-name', // Replace with your actual database name
  options: {
    encrypt: true,               // Use encryption for the connection
    trustServerCertificate: true // Trust the server's SSL certificate (no validation)
  },
  authentication: {
    type: 'ntlm',  // Use NTLM (Windows Authentication) for authentication
    options: {
      domain: 'DESKTOP-GTOMBCH',  // Your domain (or computer name if not in a domain)
    }
  }
};

// Connect to SQL Server using Windows Authentication
sql.connect(config)
  .then(pool => {
    console.log('Connected to SQL Server');
    return pool.request().query('SELECT * FROM Customers'); // Sample query
  })
  .then(result => {
    console.log(result.recordset); // Output the result of the query
  })
  .catch(err => {
    console.error('Error connecting to SQL Server:', err);
  })
  .finally(() => {
    sql.close(); // Close the connection
  });
